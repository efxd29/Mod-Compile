# Mob HP Percent (Fabric 26.3, server-side only)

Build: `./gradlew build` (JDK 25, Gradle 9.7.1, sudah ada gradlew) -> `build/libs/mobhp-1.0.1.jar`
Taruh jar di folder `mods/` server (plus Fabric API). Client tidak perlu install apa-apa.
