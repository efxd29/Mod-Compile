package dev.mobhp;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Display;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Server-side only mob HP percentage.
 * Tiap Mob dikasih 1 text_display (billboard) di atas kepalanya, di-update tiap tick.
 */
public class MobHpMod implements ModInitializer {

    // ====== SETTING ======
    private static final String TAG = "mobhp";
    private static final String HEART_COLOR = "#FF000D";
    private static final String TEXT_COLOR = "white";
    private static final int BACKGROUND_ARGB = 0xB0555555; // abu-abu semi transparan
    private static final double Y_OFFSET = 0.35;           // jarak di atas kepala mob
    private static final int MAX_SPAWN_PER_TICK = 20;      // biar ga lag pas banyak mob load barengan
    // =====================

    private static final class Tracked {
        final Mob mob;
        final ServerLevel level;
        UUID display;
        int lastPct = -1;

        Tracked(Mob mob, ServerLevel level) {
            this.mob = mob;
            this.level = level;
        }
    }

    private record Doomed(ServerLevel level, UUID id) {}

    private static final Map<UUID, Tracked> TRACKED = new HashMap<>();
    private static final Set<UUID> ACTIVE_DISPLAYS = new HashSet<>();
    private static final List<Doomed> TO_DISCARD = new ArrayList<>();
    private static final List<Entity> LEFTOVERS = new ArrayList<>();

    @Override
    public void onInitialize() {
        ServerEntityEvents.ENTITY_LOAD.register((entity, level) -> {
            if (entity instanceof Mob mob) {
                TRACKED.put(mob.getUUID(), new Tracked(mob, level));
            } else if (entity instanceof Display.TextDisplay
                    && entity.getTags().contains(TAG)
                    && !ACTIVE_DISPLAYS.contains(entity.getUUID())) {
                // sisa display dari save sebelumnya (server crash / restart)
                LEFTOVERS.add(entity);
            }
        });

        ServerEntityEvents.ENTITY_UNLOAD.register((entity, level) -> {
            if (entity instanceof Mob mob) {
                Tracked t = TRACKED.remove(mob.getUUID());
                if (t != null && t.display != null) {
                    queueDiscard(t.level, t.display);
                    t.display = null;
                }
            }
        });

        ServerTickEvents.END_SERVER_TICK.register(this::tick);

        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            // bersihin semua display sebelum world disave
            for (Tracked t : TRACKED.values()) {
                if (t.display != null) {
                    Entity d = t.level.getEntity(t.display);
                    if (d != null) d.discard();
                    t.display = null;
                }
            }
            TRACKED.clear();
            ACTIVE_DISPLAYS.clear();
            TO_DISCARD.clear();
            LEFTOVERS.clear();
        });
    }

    private void tick(MinecraftServer server) {
        // bersihin display sisa & display yang antri dihapus
        if (!LEFTOVERS.isEmpty()) {
            for (Entity e : LEFTOVERS) e.discard();
            LEFTOVERS.clear();
        }
        if (!TO_DISCARD.isEmpty()) {
            for (Doomed d : TO_DISCARD) {
                Entity e = d.level().getEntity(d.id());
                if (e != null) e.discard();
                ACTIVE_DISPLAYS.remove(d.id());
            }
            TO_DISCARD.clear();
        }

        int spawned = 0;
        Iterator<Tracked> it = TRACKED.values().iterator();
        while (it.hasNext()) {
            Tracked t = it.next();
            Mob mob = t.mob;

            if (mob.isRemoved()) {
                if (t.display != null) queueDiscard(t.level, t.display);
                t.display = null;
                it.remove();
                continue;
            }

            // mati / lagi animasi mati -> hapus display
            if (!mob.isAlive()) {
                if (t.display != null) {
                    queueDiscard(t.level, t.display);
                    t.display = null;
                }
                continue;
            }

            int pct = percent(mob);
            Vec3 pos = new Vec3(mob.getX(), mob.getY() + mob.getBbHeight() + Y_OFFSET, mob.getZ());

            if (t.display == null) {
                if (spawned >= MAX_SPAWN_PER_TICK) continue;
                UUID id = UUID.randomUUID();
                ACTIVE_DISPLAYS.add(id);
                t.display = id;
                t.lastPct = pct;
                spawned++;
                run(server, t.level, pos, String.format(Locale.ROOT,
                        "summon minecraft:text_display %.4f %.4f %.4f {UUID:%s,Tags:[\"%s\"],text:%s,"
                                + "background:%d,billboard:\"center\",alignment:\"center\",shadow:0b,"
                                + "see_through:0b,default_background:0b,line_width:200,teleport_duration:2}",
                        pos.x, pos.y, pos.z, uuidSnbt(id), TAG, textSnbt(pct), BACKGROUND_ARGB));
                continue;
            }

            Entity display = t.level.getEntity(t.display);
            if (display == null) {
                // display ilang (chunk/kill/dll) -> bikin ulang di tick berikutnya
                ACTIVE_DISPLAYS.remove(t.display);
                t.display = null;
                continue;
            }

            display.setPos(pos.x, pos.y, pos.z);

            if (pct != t.lastPct) {
                t.lastPct = pct;
                run(server, t.level, pos, "data modify entity " + t.display + " text set value " + textSnbt(pct));
            }
        }
    }

    /** Persen HP, dibulatkan ke atas: mob yang masih hidup minimal 1%, 100% cuma kalau full. */
    private static int percent(Mob mob) {
        double max = mob.getMaxHealth();
        if (max <= 0) return 0;
        double hp = Math.min(mob.getHealth(), max);
        double pct = Math.ceil(hp * 100.0 / max);
        return (int) Math.max(1, Math.min(100, pct));
    }

    private static String textSnbt(int pct) {
        return "{text:\"\",extra:[{text:\"" + pct + "%\",color:\"" + TEXT_COLOR + "\"},"
                + "{text:\"\u2764\",color:\"" + HEART_COLOR + "\"}]}";
    }

    private static String uuidSnbt(UUID id) {
        long m = id.getMostSignificantBits();
        long l = id.getLeastSignificantBits();
        return "[I;" + (int) (m >> 32) + "," + (int) m + "," + (int) (l >> 32) + "," + (int) l + "]";
    }

    private static void queueDiscard(ServerLevel level, UUID id) {
        TO_DISCARD.add(new Doomed(level, id));
    }

    private static void run(MinecraftServer server, ServerLevel level, Vec3 pos, String command) {
        CommandSourceStack src = server.createCommandSourceStack()
                .withSuppressedOutput()
                .withLevel(level)
                .withPosition(pos);
        server.getCommands().performPrefixedCommand(src, command);
    }
}
